.. pathspec documentation master file, created by
   sphinx-quickstart on Fri Sep  8 09:37:49 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Welcome to pathspec's documentation!
==============================================

.. toctree::
   :caption: Contents:
   :maxdepth: 2

   readme
   api
   changes
   upgrading


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
